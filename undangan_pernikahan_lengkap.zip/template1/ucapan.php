<html><body style="background-color:black; color:white; font-family:sans-serif; padding:20px;">
<h2>Ucapan & Doa</h2>
<pre><?php echo file_get_contents("data_ucapan.txt"); ?></pre>
<a href="index.php" style="color:white;">Kembali</a>
</body></html>